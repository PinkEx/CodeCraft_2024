import time
import threading

from constant import *
from variable import *

from input_utils import *
from solve_utils import *

if __name__ == "__main__":
    t = time.time()
    t_init = threading.Thread(target=input_map)
    t_init.start()
    t_init.join()
    t0 = time.time()
    sys.stderr.write(f"input map timing consumption: {int((t0 - t) * 1000)}ms\n")
    for frame in range(n_f):
        # t1 = time.time()
        # input_frame()
        # t2 = time.time()
        # solve_frame(frame)
        # t3 = time.time()
        # sys.stderr.write(f"input/solve timing consumption: {int((t2 - t1) * 1000)}ms, {int((t3 - t2) * 1000)}ms\n")

        t1 = time.time()
        try:
            t_input = threading.Thread(target=input_frame)
            t_input.start()
            t_input.join()
        except Exception:
            terminal_flag = True
            break

        t2 = time.time()
        try:
            t_solve = threading.Thread(target=solve_frame, args=(frame, ))
            t_solve.start()
            t_solve.join()
        except Exception:
            terminal_flag = True
            break
        t3 = time.time()

        sys.stderr.write(f"input timing consumption @ frame {frame + 1}: {int((t2 - t1) * 1000)}ms\n")
        sys.stderr.write(f"input/solve timing consumption: {int((t2 - t1) * 1000)}ms, {int((t3 - t2) * 1000)}ms\n")